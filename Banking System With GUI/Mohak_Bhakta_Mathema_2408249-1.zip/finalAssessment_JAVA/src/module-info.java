/**
 * 
 */
/**
 * 
 */
module finalAssessment_JAVA {
	requires java.desktop;
}